//: Playground - noun: a place where people can play

import UIKit

var str = "Hello, playground"


// exercise 3 

// 3. 1 Average 

var a = 2.0

var b = 5.0

var c = Double(a+b)/2


// 3.2 Wieghted mean

var finalsGrade = 2.0

var midtermGrade = 4.0

var projectGrade = 3.0


var finalgrade = ((finalsGrade * 50) / 100 )  +  ((midtermGrade * 20) / 100 )  +  ((projectGrade * 30 / 100 ) )

print(finalsGrade)


// 3.3 Tipping

var mealCost:Double = 3.5

var tip:Int = 20

var total_cost:Double =  (mealCost * Double (tip )) / 100 + mealCost

print("Total cost after tip \(total_cost)")

// 3.4 Rounding

import Foundation

var number = 5.1517

number = round(number)

// 3.5 Above Average 

var grade1 = 7.0

var grade2 = 9.0

var grade3 = 5.0

var yourGrade = (grade1 + grade2 + grade3) / 3

var class_avaerage = 6.5

if (yourGrade > class_avaerage)
{
    print("Your grades are above average")
}

else
    
{
    print("Your grades are below average")
 
}

// 3.6 Fields 

var numberOfFields:Int = 5

var wheatYield:Double = 7.5

var weatherWasGood:Bool = true

var total_harvest =  (Double (numberOfFields ) * wheatYield)

if (weatherWasGood == true)
{
    
    total_harvest = total_harvest * 1.5
    
    
}

print(total_harvest)


// Exercise 4 

// 4.1 Chalkboard


var N = 10

// with a while loop
var n = 0
while n < N
{
    
    print("I will not skip the fundamentals!")
    n = n + 1
}

// solution 2 


for _ in 1...N {
    print("I will not skip the fundamentals!")
}


// 4.2 Squares


var count = 1

while count <= N {
    
    print(count * count)
    
    count = count + 1
}


// 4.3 Power of 2

var N1 = 8

var power = 2

for _ in power..<N1
{
    print(power)
    power = power * 2
}


// 4.4 Alternate counting 




// 4.5 Sqaure

var N2 = 4

for i in 1...N2 {
    for j in 1...N2 {
        print("*", terminator: "")
    }
    print("")
}

// 4.6 Rectangle

var N3 = 4

var M3 = 6

for i in 1...N3 {
    for j in 1...M3{
        
        print("*" , terminator: "")
    }
    
    print ("")
}

// 4.7 Tringle 

var N4 = 4

for i in 1...N4 {
    for j in  1...i{
        
        print("*" , terminator: "")
    }
    
    print ("")
}

// 4.8  Fibonacci

var F = 10
var f = 0;
var g = 1;

for i in 1...F
{
    f = f + g;
    g = f - g;
    
    print(f)
    
}

// 4.9 Reverese Number


var num = 12345

while num > 0 {
    print(num % 10, terminator: "")
    num /= 10
}

// 4.10 Prime numbers 


var flag = 0

var num1 = 17

for i in 1...num1 {
    if num1 % i == 0 {
        flag += 1
    }
}

if flag == 2 {
    print("prime")
} else {
    print("not prime")
}


//  Exercise 5 

// 5.1 Full name


var firstName = "Johnson"

var lastName = "Christian"

var fullname = firstName + " " + lastName

print(fullname)

// 5.2 Sum

var a1 = 14

var b1 = 23

var formattedSum = a1 + b1

print("For a = \(a1) and b = \(b1) formated sum = \(a1) + \(b1) = \(formattedSum)" )


// 5. 3  Replace character 

var aString = "Replace the letter e with *"

var replacestring = ""

for character in aString.characters
{
    var char = " \(character)"
    
    if char == "e"
    {
        replacestring  =  replacestring + "*"
    }
    else
    
    {
        replacestring  =  replacestring + char
    }
    
}


// 5.4 Reverse

var string = " my name is john"

var charasters = string.characters

var reverse_string = charasters.reversed()


print(reverse_string)


// 5.5 Palindrome

var original_string = "kanak"

var reverse_stirng = ""

for character in original_string.characters {
    var char = "\(character)"
    reverse_stirng  = char + reverse_stirng
}

if (aString == reverse_stirng)
{
    print("true")
}
else{
    print("false")
}


// 5.6 Words
var word_string = "split this string into words and print them on separate lines"

var word = ""

for char in word_string.characters {
    if char == " " {
        print(word)
        word = ""
    } else {
        word .append(char)
}
}

print(word)


// 5.7 Long word



// 5.8 Magic Time 

func *(string: String, scalar: Int) -> String {
    let array = Array(repeating: string, count: scalar)
    return array.joined(separator: "") }

var num2 = 5
var num3 = 2

var newLine = "\n" * 2


var line = "*" * num2
line += newLine

var pattern: String = line * num3

print(pattern)


